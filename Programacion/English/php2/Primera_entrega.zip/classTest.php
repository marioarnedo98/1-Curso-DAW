<?php

class Principal{
	public $id = 23;
	protected $name = 'Mario Test';

	public function hellothere($word){
		echo $word;
	}
}

class Second extends Principal{
	public function getName(){
		echo $this->name;
	}
}

$second = new Second;

echo $second->getName();

//echo $second->hellothere('Hello World');