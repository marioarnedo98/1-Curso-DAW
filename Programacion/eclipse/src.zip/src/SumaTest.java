import static org.junit.Assert.*;

import org.junit.Test;


public class SumaTest {

	@Test
	public void sumaPositivios() {
		
	}

	@Test
	public void sumaNegativos() {
		
	}
	
	@Test
	public void sumaPositivioNegativo() {
		
	}
}
