
public class Suma {
	
	private int sumando1, sumando2;
	
	public Suma(int n1, int n2){
		sumando1 = n1;
		sumando2 = n2;
	}
	
	public int sumar(){
		int resultado = sumando1 + sumando2;
		return resultado;
	}

}
