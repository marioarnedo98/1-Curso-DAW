package lastexam;

public class Ghost extends Enemy {

	public Ghost(String name, String description, int health) {
		super(name, description, health);
		int secretWeapon = 1;
	}

}
