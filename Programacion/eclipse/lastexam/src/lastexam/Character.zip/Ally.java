package lastexam;

public class Ally extends Character {
	public Ally(String name, String description, int health) {
		this.setName(name);
		this.setDescription(description);
		this.setHealth(health);
	}
}
