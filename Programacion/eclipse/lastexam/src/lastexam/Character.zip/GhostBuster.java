package lastexam;

public class GhostBuster extends Ally {

	public GhostBuster(String name, String description, int health) {
		super(name, description, health);
		int secretWeapon = 2;
	}

}
